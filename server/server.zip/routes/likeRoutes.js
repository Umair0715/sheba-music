const router = require('express').Router();
const { protect } = require('../middlewares/protect');
const likeController = require('../controllers/likeController');

router.post('/' , protect , likeController.createLike);
router.get('/:postId' , protect , likeController.getPostLikes);


module.exports = router;