const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const Like = require('../models/likeModel');
const { sendSuccessResponse } = require('../utils/helpers')


exports.createLike = catchAsync( async(req , res , next) => {
    const { postId } = req.body;
    if(!postId){
        return next(new AppError('Please provide post id which you want to like.' , 400))
    }
    const likeExist = await Like.findOne({ postId , user : req.user._id , like : 1 })
    if(likeExist){
        await likeExist.remove();
        return sendSuccessResponse(res , 200 , {
            message : 'Like removed.'
        })
    }
    await Like.create({ postId , like : 1 , user : req.user._id });
    return sendSuccessResponse(res , 201 , {
        message : "Like created."
    })
});

exports.getPostLikes = catchAsync( async(req , res , next) => {
    const { postId } = req.params;
    if(!postId){
        return next(new AppError('Please provide post id in params.' , 400))
    }
    const likesCount = await Like.countDocuments({ postId });
    return sendSuccessResponse(res , 200 , {
        likesCount 
    })
})