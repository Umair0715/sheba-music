const catchAsync = require('../../utils/catchAsync');
const AppError = require('../../utils/appError');
const Category = require('../../models/categoryModel');
const { sendSuccessResponse } = require('../../utils/helpers');

//URL  =>  Method  =>  Access

//api/category  =>  POST  => Admin 
exports.createCategory = catchAsync(async(req , res ,next ) => {
    const { name , parentId } = req.body;
    let newCategory ;
    if(parentId){
        newCategory = await Category.create({
            name , parentId , user : req.user._id 
        });
    }else {
        newCategory = await Category.create({
            name , user : req.user._id 
        })
    }
    return sendSuccessResponse(res , 201 , {
        message : 'New Category created.' , 
        category : newCategory
    });
});

//api/category  =>  GET  => Admin + user
exports.getCategories = catchAsync(async(req , res ,next ) => {
    const categories = await Category.find({ isActive : true }).populate('parentId' , '-__v');
    return sendSuccessResponse(res , 200 , { categories })
});

//api/category/:id  =>  PUT  => Admin 
exports.updateCategory = catchAsync(async(req , res ,next ) => {
    const { id } = req.params;
    const updatedCategory = await Category.findByIdAndUpdate(id , req.body , {
        new : true 
    }).populate('parentId' , '-__v');
    return sendSuccessResponse(res , 200 , { category : updatedCategory })
});

//api/category/:id  =>  DELETE  => Admin 
exports.deleteCategory = catchAsync(async(req , res , next ) => {
    const { id } = req.params;
    const category = await Category.findById(id).populate('parentId');
    if(category.parentId){
        category.isActive = false;
        await category.save();
        return sendSuccessResponse(res , 200 , { 
            message : 'Category deleted.'
        })
    }else {
        const subCategories = await Category.find({ parentId : id , isActive : true  });
        await Promise.all(subCategories.map(async (category) => {
            category.isActive = false ;
            return await category.save();
        }));
        category.isActive = false;
        await category.save();
        return sendSuccessResponse( res , 200 , { 
            message : 'Category deleted.'
        })
    }
});

exports.getSingleCategory = catchAsync( async(req , res , next ) => {
    const { id } = req.params;
    const category = await Category.findOne({ _id : id , isActive : true })
    .populate('parentId' , '-__v');
    return sendSuccessResponse(res , 200 , {
        category 
    })
});