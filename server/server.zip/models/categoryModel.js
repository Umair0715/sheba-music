const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
    name : {
        type : String ,
        required : true 
    } ,
    parentId : {
        type : mongoose.Schema.ObjectId ,
        ref : "Category" ,
    } ,
    isActive : {
        type : Boolean , 
        default : true 
    } ,
    user : {
        type : mongoose.Schema.ObjectId ,
        ref : 'User'
    }

} , { timestamps : true });

const Category = mongoose.model('Category' , categorySchema);
module.exports = Category;