const mongoose = require('mongoose');

const likeSchema = new mongoose.Schema({
    postId : {
        type : String ,
        required : true 
    } ,
    like : {
        type : Number ,
        // 1 = like , 0 = noLike 
    },
    user : {
        type : mongoose.Schema.ObjectId ,
        ref : 'User' ,
        required : true 
    }
} , { timestamps : true });

const Like = mongoose.model('Like' , likeSchema);
module.exports = Like;