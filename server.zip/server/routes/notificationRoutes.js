const router = require('express').Router();
const notificationController = require('../controllers/notificationController');
const { protect } = require('../middlewares/protect');

router.post('/' , protect , notificationController.createNotification);
router.get('/' , protect , notificationController.getNotifications);

module.exports = router;