const router = require('express').Router();
const categoryController = require('../../controllers/admin/categoryController');
const { protect , isAdmin } = require('../../middlewares/protect');


router.route('/' )
    .post(protect , isAdmin , categoryController.createCategory)
    .get( categoryController.getCategories);

router.route('/:id')
    .put(protect , isAdmin , categoryController.updateCategory)
    .delete(protect , isAdmin , categoryController.deleteCategory)
    .get(categoryController.getSingleCategory);
    
module.exports = router;