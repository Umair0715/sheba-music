const router = require('express').Router();
const { protect } = require('../middlewares/protect');
const followController = require('../controllers/followController');

router.route('/')
    .post( protect , followController.createFollower)
    .get( protect , followController.getMyFollowers)
router.route('/:userId')
    .delete( protect , followController.unFollowUser)
    .get(protect , followController.getSingleUserFollowers);

module.exports = router;