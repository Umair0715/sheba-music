const router = require('express').Router();
const albumController = require('../controllers/albumController');
const { protect } = require('../middlewares/protect');

router.route('/')
    .post( protect , albumController.createAlbum)
    .get( protect , albumController.getMyAlbums);

router.route('/:id')
    .put(protect , albumController.updateAlbum)
    .delete(protect , albumController.deleteAlbum)
    .get(albumController.getSingleAlbum);

router.get('/list' , albumController.getAllAlbums);
router.delete('/:albumId/delete-song/:songId' , protect , albumController.deleteAlbumSong);
router.put('/change-image/:id' , protect , albumController.changeAlbumImage);
router.put('/addSongs/:id' , protect , albumController.addSongsInAlbum);

module.exports = router;