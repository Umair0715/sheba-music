const catchAsync = require('../utils/catchAsync');
const Notification = require('../models/notificationModel');

exports.createNotification = catchAsync( async(req , res) => {
    const { activity } = req.body;
    const notification = await Notification.create({ 
        activity , 
        user : req.user._id 
    });

    return res.status(201).json({
        status : 'success' ,
        success : true ,
        data : {
            message : 'Notification created.' , 
            notification 
        }
    })
});

exports.getNotifications = catchAsync( async(req , res , next) => {
    const notifications = await Notification.find().populate('user' , 'name email phone');

    return res.status(201).json({
        status : 'success' ,
        success : true ,
        data : {
            notifications
        }
    })
})