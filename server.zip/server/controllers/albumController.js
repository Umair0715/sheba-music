const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const Album = require('../models/albumModel');
const { sendSuccessResponse , uploadImage  } = require('../utils/helpers');

// /api/album => POST => protected
exports.createAlbum = catchAsync(async ( req , res , next ) => {
    const { name , image } = req.body;
    if(!name || !image){
        return next(new AppError('Missing required credentials.' , 400))
    };
    const uploadedImage = uploadImage(image , 'albums');
    req.body.image = uploadedImage;
    req.body.albumCreator = req.user._id;

    let newAlbum = await Album.create(req.body);
    newAlbum = await Album.findById(newAlbum._id).populate({
        path : 'albumCreator' ,
        select : 'name email phone' 
    }).populate({
        path : 'songs',
        populate : {
            path : 'song' ,
            select : '-__v',
            populate : {
                path : 'songCreator',
                select : 'name email phone'
            }
        }
    });
  
    return sendSuccessResponse(res , 201 , {
        message : 'New album created.', 
        album : newAlbum
    });
});

// /api/album => GET => protected 
exports.getMyAlbums = catchAsync( async ( req , res , next ) => {
    const albums = await Album.find({ user : req.user._id , isActive : true }).populate('albumCreator' , 'name email phone').populate({
        path : 'songs',
        populate : {
            path : 'song' ,
            select : 'title audio category songCover songCreator',
            populate : {
                path : 'songCreator',
                select : 'name email phone'
            }
        }
    });
    return sendSuccessResponse(res , 200 , {
        albums 
    });
});

// /api/album/:id => PUT => protected 
exports.updateAlbum = catchAsync( async(req , res , next) => {
    const { id } = req.params;
    const updatedAlbum = await Album.findByIdAndUpdate(id , req.body , {
        new : true ,
        runValidators : true 
    }).populate('albumCreator' , 'name email phone').populate({
        path : 'songs',
        populate : {
            path : 'song' ,
            select : 'title audio category songCover songCreator' ,
            populate : {
                path : 'songCreator',
                select : 'name email phone'
            }
        }
    });
    return sendSuccessResponse(res , 200 , {
        album : updatedAlbum
    })
});

// /api/album/:id => DELETE => protected
exports.deleteAlbum = catchAsync( async ( req , res , next ) => {
    const { id } = req.params;
    await Album.findByIdAndUpdate(id , {
        isActive : false 
    } , { new : true });
    return sendSuccessResponse(res , 200 , {
        message : 'Album deleted.'
    })
});

// /api/album/:id => PUT => protected
exports.addSongsInAlbum = catchAsync( async ( req , res , next ) => {
    const { songs } = req.body;
    let updatedAlbum = await Album.findByIdAndUpdate(req.params.id , {
        $addToSet  : {  songs : songs } 
    } , { new : true });

    updatedAlbum = await Album.findById(updatedAlbum._id).populate('albumCreator' , 'name email phone')
    .populate({
        path : 'songs' ,
        populate : {
            path : 'song' , 
            select : '-__v' ,
            populate : {
                path : "songCreator",
                select : "name email phone"
            }
        }
    });

    return sendSuccessResponse(res , 200 , {
        message : 'Album updated.' ,
        album : updatedAlbum
    }); 
});

exports.getAllAlbums = catchAsync(async ( req , res , next) => {
    const pageSize = 10 ;
    const page = Number(req.query.page) || 1;
    const albums = await Album.find()
    .limit(pageSize).skip(pageSize * (page - 1 ))
    .populate('albumCreator' , 'name email phone')
    .populate({
        path : 'songs',
        populate : {
            path : 'song' ,
            select : '-__v' ,
            populate : {
                path : 'songCreator',
                select : 'name email phone'
            }
        } 
    });
    
    return sendSuccessResponse( res , 200 , {
        albums 
    });
});

exports.getSingleAlbum = catchAsync( async ( req , res , next ) => {
    const { id } = req.params;
    const album = await Album.findOne({ _id : id , isActive : true })
    .populate('albumCreator' , 'name email phone')
    .populate({
        path : 'songs',
        populate : {
            path : 'song' ,
            select : '-__v' ,
            populate : {
                path : 'songCreator',
                select : 'name email phone'
            }
        } 
    });
    return sendSuccessResponse(res , 200 , {
        album 
    })

});

exports.deleteAlbumSong = catchAsync( async ( req , res ) => {
    const { albumId , songId } = req.params;
    const album = await Album.findById(albumId);
    album.songs = album.songs.filter(song => song.song.toString() !== songId.toString() );
    await album.save();
    return sendSuccessResponse(res , 200 , {
        message : 'Song delete successfully.'
    });
});

exports.changeAlbumImage = catchAsync(async(req , res , next) => {
    let { image } = req.body;
    image = uploadImage(image , 'albums');
    let updatedAlbum = await Album.findByIdAndUpdate(req.params.id , { image } , {
        new : true ,
        runValidators : true 
    });
    return sendSuccessResponse(res , 200 , {
        album : updatedAlbum
    })
}); 