const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const { sendSuccessResponse , sendErrorResponse } = require('../utils/helpers');
const BuySong = require('../models/buySongModel');
const Wallet = require('../models/walletModel');
const WalletHistory = require('../models/walletHistoryModel');
const Song = require('../models/songModel');
const User = require('../models/userModel');
const TagInfluencer = require('../models/tagInfluencerModel');
const AdminCommission = require('../models/commissionModel');


const createWalletHistory = async (type , amount , user , wallet , description) => {
    await WalletHistory.create({ 
        type , 
        amount ,
        user ,
        wallet , 
        description 
    })
}

const sendBuySongErrorResponse = async (buyerWallet , songOwnerWallet , influencerWallet , influencerProfit , statusCode = 500 , message , buySongId) => {
    if(buySongId){
        await BuySong.findByIdAndDelete(buySongId);
    }
    buyerWallet.totalBalance = buyerWallet.totalBalance + songToBuy.license.amount;
    await buyerWallet.save();

    if(influencerWallet){
        influencerWallet.totalBalance = influencerWallet.totalBalance - influencerProfit;
        await influencerWallet.save();
        songOwnerWallet.totalBalance = songOwnerWallet.totalBalance - (songToBuy.license.amount - influencerProfit);
        await songOwnerWallet.save();
    }else{
        songOwnerWallet.totalBalance = songOwnerWallet.totalBalance - songToBuy.license.amount;
        await songOwnerWallet.save();
    }
    return sendErrorResponse(res , statusCode , {
        message 
    })
}

exports.buySong = catchAsync( async(req , res , next) => {
    // 1) Validation
    const { buyer , song , influencer } = req.body;
    if(!buyer || !song ){
        return next(new AppError('Missing required credentials.' , 400))
    }
    // 2) check buyer wallet amount enough for a song
    const songToBuy = await Song.findById(song);
    const songOwner = await User.findById(songToBuy.songCreator);
    let buyerWallet = await Wallet.findOne({ 
        user : buyer , isActive : true
    }).populate('user' , 'name email phone');
    const songOwnerWallet = await Wallet.findOne({ 
        user : songOwner._id , isActive : true 
    });
    const adminWallet = await Wallet.findById('636269b5dd7742b2983a2a8d');
    
    if(buyer.toString() === songOwner._id.toString()){
        return next(new AppError('You cannot buy your own songs.' , 400))
    }
    if(songToBuy.license.type === 0 ){
        return next(new AppError('This song is free' , 400))
    }
    if(buyerWallet.totalBalance < songToBuy.license.amount){
        return next(new AppError('You have insufficient balance to buy this song. ' , 400 ))
    }
    // 3) check song already purchased by given user or not.
    const isSongBuyed = await BuySong.findOne(
        { buyer , songOwner , song , isActive : true }
    )
    if(isSongBuyed){
        return next(new AppError('You have already buy this song.' , 400))
    }
    // 4) subtract song amount from buyer wallet
    buyerWallet.totalBalance = buyerWallet.totalBalance - songToBuy.license.amount;
    await buyerWallet.save();
  
    // 6) Create Buy Song
    try {
        const newBuySong = await BuySong.create({
            buyer  ,
            song , 
            songOwner : songOwner._id ,
            influencer : 0 
        });
        // 7)  if Influencer exist then calculate it's profit and add amount  (skip for now )
        if(influencer){
            //check influencer exist in database
            try {
                const influencerExist = await User.findOne({ 
                    _id : influencer , isActive : true , userType : 4 
                });
    
                if(!influencerExist){
                    await BuySong.findByIdAndDelete(newBuySong._id);
                    return await sendBuySongErrorResponse(
                        buyerWallet , songOwnerWallet , null , 0 , 404 , 'This Influencer is not exist' , newBuySong._id
                    );
                }
                //check this is influencer of a songowner
                const _influencer = await TagInfluencer.findOne({ 
                    user : songOwner._id , isActive : true , influencer 
                });
                
                if(!_influencer){
                    await BuySong.findByIdAndDelete(newBuySong._id);
                    return await sendBuySongErrorResponse(
                        buyerWallet , 
                        songOwnerWallet , 
                        null ,
                        0 ,
                        404 ,
                        'Song owner removed this influencer from his influencer list.' , 
                        newBuySong._id
                    );
                }
                const influencerWallet = await Wallet.findOne({
                    user : influencer , isActive : true 
                })
                
                const influencerProfit = ( songToBuy.license.amount / 100 ) * _influencer.profitPercentage;
                influencerWallet.totalBalance = influencerWallet.totalBalance + influencerProfit;
                await influencerWallet.save();
                // create influencer history for earning amount
                await createWalletHistory(2 , influencerProfit , _influencer._id , influencerWallet , 'Someone purchase a shared song.')
                
                // add song amount to songOwner wallet
                songOwnerWallet.totalBalance = songOwnerWallet.totalBalance + (songToBuy.license.amount - influencerProfit) ;
                await songOwnerWallet.save();
                
                //create wallet history
                await createWalletHistory( 2 , songToBuy.license.amount - influencerProfit , songOwner._id , songOwnerWallet , "Someone purchased a song." )
            } catch (error) {
                if(influencer && influencerWallet){
                    return await sendBuySongErrorResponse(
                        buyerWallet , 
                        songOwnerWallet , 
                        influencerWallet ,
                        influencerProfit ,
                        500 ,
                        'Internal server error.' ,
                        newBuySong._id
                    );
                }else{
                    return await sendBuySongErrorResponse(
                        buyerWallet , 
                        songOwnerWallet , 
                        null ,
                        0 ,
                        500 ,
                        'Internal server error.', 
                        newBuySong._id
                    );
                }
            }

        }else{
            //  add song amount to songOwner wallet
            songOwnerWallet.totalBalance = songOwnerWallet.totalBalance + songToBuy.license.amount;
            await songOwnerWallet.save();
            await createWalletHistory( 2 , songToBuy.license.amount , songOwner._id , songOwnerWallet , "Someone purchased a song." )
        }

        // 8) create buyer history for purchase a song 
        await createWalletHistory( 3 , songToBuy.license.amount , buyer , buyerWallet , 'Purchased a song.')
    

        // 11) send Response
        return sendSuccessResponse( res , 201 , {
            message : 'Song purchased successfully.' , 
            song : newBuySong 
        });
    } catch (error) {
        return await sendBuySongErrorResponse(
            buyerWallet , 
            songOwnerWallet , 
            null ,
            0 ,
            500 ,
            'Internal server error.' , 
            null
        );
    }
});


exports.getMyBuySongs = catchAsync( async(req , res , next) => {
    const songs = await BuySong.find({ 
        buyer : req.user._id , 
        isActive : true
    })
    .populate('buyer' , 'name email phone')
    .populate('song' , 'title audio songCover license')
    .populate('songOwner' , 'name email phone');
    
    return sendSuccessResponse(res , 200 , {
        songs 
    })
});