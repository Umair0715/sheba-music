const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const Follow = require('../models/followModel');
const { sendSuccessResponse } = require('../utils/helpers');


exports.createFollower = catchAsync( async(req , res , next) => { 
    const { userId } = req.body;
    const followerId = req.user._id;
    if(!userId) {
        return next(new AppError('User id is required.' , 400))
    }
    const followerExist = await Follow.findOne({ userId , followerId , isActive : true });
    if(followerExist){
        return next(new AppError('You have already followed this user.' , 400))
    }
    let newFollower = await Follow.create({ 
        userId , followerId 
    });
    newFollower = await Follow.findById({ _id : newFollower._id})
    .populate('userId' , 'name email phone')
    .populate('followerId' , 'name email phone');

    return sendSuccessResponse(res , 201 , {
        message : "New follower added." , 
        newFollower 
    });

});

exports.getMyFollowers = catchAsync( async(req , res , next) => {
    const pageSize = 10;
    const page = Number(req.query.page) || 1;

    const followers = await Follow.find({ userId : req.user._id , isActive : true }).limit(pageSize).skip(pageSize * (page - 1 ))
    .populate('userId' , 'name email phone')
    .populate('followerId' , 'name email phone');

    return sendSuccessResponse(res , 200 , {
        followers 
    })
});


exports.unFollowUser = catchAsync( async(req , res , next) => {
    const { userId } = req.params;
    await Follow.findOneAndUpdate({ userId } , { isActive : false });
    return sendSuccessResponse(res , 200 , {
        message : 'Done',
    }) 
});

exports.getSingleUserFollowers = catchAsync( async(req , res , next) => {
    const pageSize = 10 ;
    const page = Number(req.query.page) || 1;
    const followers = await Follow.find({ userId : req.params.userId  , isActive : true })
    .limit(pageSize).skip(pageSize * (page - 1 ))
    .populate('userId' , 'name email phone')
    .populate('followerId' , 'name email phone')
    
    return sendSuccessResponse(res , 200 , {
        followers
    })
});