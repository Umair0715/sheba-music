const mongoose = require('mongoose');

const followSchema = new mongoose.Schema({
    userId : {
        type : mongoose.Schema.ObjectId ,
        ref : 'User' ,
        required : [true , 'User id is required.']
    } ,
    followerId : {
        type : mongoose.Schema.ObjectId ,
        ref : 'User' ,
        required : [true , 'FollowerId is required.']
    },
    isActive : {
        type : Boolean ,
        default : true 
    }
}, { timestamps : true });


const Follow = mongoose.model('Follow' , followSchema);
module.exports = Follow;